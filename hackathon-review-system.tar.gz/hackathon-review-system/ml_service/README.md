# ML/NLP 服务

这是Hackathon Review System的机器学习和自然语言处理服务，负责评估评论的质量和相关性。

## 目录结构

```
ml_service/
├── app.py                    # Flask API主应用
├── requirements.txt          # Python依赖包
├── models/                   # ML模型文件目录
├── utils/
│   └── nlp_processor.py     # NLP处理工具
└── README.md                # 本文件
```

## 功能特性

### 1. 评论质量评估
- **质量评分**: 基于内容质量、语言表达等因素评分
- **垃圾检测**: 识别广告、推广等垃圾内容
- **情感分析**: 分析评论的情感倾向

### 2. 相关性评估
- **主题相关性**: 判断评论内容是否与地点相关
- **关键词提取**: 提取评论中的关键信息
- **语言检测**: 自动识别评论语言

### 3. 政策违规检测
- **广告检测**: 识别包含推广链接或广告内容的评论
- **无关内容检测**: 发现与地点无关的评论内容
- **虚假评论检测**: 识别可能来自未访问用户的抱怨

## 快速开始

### 1. 环境要求

- Python 3.8 或更高版本
- pip 包管理器

### 2. 安装依赖

```bash
cd ml_service

# 安装基础依赖（当前示例版本）
pip install Flask Flask-CORS

# 或安装完整依赖（用于完整ML/NLP实现）
# pip install -r requirements.txt
```

### 3. 启动服务

```bash
# 开发模式启动
python app.py

# 或使用环境变量配置
export PORT=5000
export DEBUG=True
python app.py

# 生产模式启动（需要安装gunicorn）
# gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

服务将在 `http://localhost:5000` 启动。

### 4. 测试API

```bash
# 健康检查
curl http://localhost:5000/ml-api/health

# 评论评估
curl -X POST http://localhost:5000/ml-api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "text": "这家餐厅的服务很好，食物也很美味。",
    "metadata": {
      "location_name": "测试餐厅"
    }
  }'
```

## API 接口

### 1. 评论评估 `/ml-api/predict`

**请求方法**: POST

**请求体**:
```json
{
  "text": "评论文本内容",
  "metadata": {
    "location_name": "地点名称（可选）",
    "location_id": "地点ID（可选）"
  }
}
```

**响应**:
```json
{
  "quality_score": 0.85,
  "relevancy_score": 0.92,
  "policy_violations": {
    "advertisement": false,
    "irrelevant_content": false,
    "rant_without_visit": false
  },
  "metadata": {
    "text_length": 25,
    "processed_at": "2024-01-01T12:00:00",
    "model_version": "1.0.0"
  }
}
```

### 2. 健康检查 `/ml-api/health`

**请求方法**: GET

**响应**:
```json
{
  "status": "healthy",
  "service": "ML/NLP Review Assessment Service",
  "version": "1.0.0",
  "timestamp": "2024-01-01T12:00:00"
}
```

### 3. 模型信息 `/ml-api/model-info`

**请求方法**: GET

**响应**:
```json
{
  "model_name": "Review Assessment Model",
  "model_version": "1.0.0",
  "model_type": "Rule-based (Demo)",
  "supported_languages": ["zh-CN", "en"],
  "features": [
    "Quality scoring",
    "Relevancy assessment",
    "Policy violation detection"
  ]
}
```

## 当前实现

### 1. 规则基础模型
当前版本使用基于规则的方法来模拟ML模型行为：

- **关键词匹配**: 使用预定义的关键词列表进行分类
- **简单评分**: 基于词汇统计的评分算法
- **模式识别**: 使用正则表达式检测特定模式

### 2. NLP处理工具
`utils/nlp_processor.py` 提供了基础的NLP功能：

- 文本预处理和清理
- 关键词提取
- 情感分析
- 特征提取

## 升级到真实ML模型

### 1. 数据准备

```python
# 示例：加载和预处理数据
import pandas as pd
from sklearn.model_selection import train_test_split

# 加载数据集
data = pd.read_csv('review_dataset.csv')

# 数据预处理
# ... 数据清理和特征工程

# 分割训练和测试集
X_train, X_test, y_train, y_test = train_test_split(
    features, labels, test_size=0.2, random_state=42
)
```

### 2. 模型训练

```python
# 示例：使用HuggingFace Transformers
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer

# 加载预训练模型
model_name = "bert-base-chinese"  # 或其他适合的模型
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(
    model_name, 
    num_labels=3  # 质量分类：高、中、低
)

# 训练模型
# ... 训练代码
```

### 3. 模型集成

```python
# 在app.py中集成训练好的模型
class ReviewAssessmentModel:
    def __init__(self):
        # 加载训练好的模型
        self.tokenizer = AutoTokenizer.from_pretrained('./models/tokenizer')
        self.quality_model = AutoModelForSequenceClassification.from_pretrained('./models/quality_model')
        self.relevancy_model = AutoModelForSequenceClassification.from_pretrained('./models/relevancy_model')
    
    def assess_review(self, text, metadata=None):
        # 使用真实模型进行预测
        # ... 预测代码
        pass
```

## 部署

### 1. Docker部署

创建 `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

### 2. 云服务部署

- **AWS**: 使用ECS或Lambda部署
- **Google Cloud**: 使用Cloud Run或App Engine
- **Azure**: 使用Container Instances或App Service

## 性能优化

### 1. 模型优化
- 模型量化和压缩
- 批处理推理
- 模型缓存

### 2. 服务优化
- Redis缓存常见请求
- 异步处理长时间任务
- 负载均衡和水平扩展

## 监控和日志

### 1. 性能监控
- 响应时间监控
- 错误率统计
- 资源使用监控

### 2. 模型监控
- 预测准确率跟踪
- 数据漂移检测
- A/B测试支持

## 故障排除

### 1. 常见问题

**模型加载失败**:
- 检查模型文件路径
- 确认依赖包版本兼容性

**内存不足**:
- 减少批处理大小
- 使用模型量化
- 增加服务器内存

**预测速度慢**:
- 启用GPU加速
- 使用模型并行
- 优化预处理流程

### 2. 调试技巧

```python
# 启用详细日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 性能分析
import cProfile
cProfile.run('model.assess_review(text)')
```

## 下一步开发

1. **数据收集**: 收集和标注更多训练数据
2. **模型训练**: 训练专门的质量和相关性评估模型
3. **特征工程**: 开发更复杂的文本特征
4. **多语言支持**: 扩展到更多语言
5. **实时学习**: 实现在线学习和模型更新
6. **API优化**: 添加批处理和异步处理支持

