# 前端 Web 应用

这是Hackathon Review System的前端Web应用，提供用户友好的界面来评估评论质量和相关性。

## 目录结构

```
frontend/
├── index.html            # 主页面
├── css/
│   └── style.css         # 样式文件
├── js/
│   └── main.js           # 主要JavaScript逻辑
├── assets/               # 静态资源目录（图片、图标等）
└── README.md            # 本文件
```

## 功能特性

### 1. 用户界面
- **响应式设计**: 支持桌面和移动设备
- **现代化UI**: 使用渐变背景、卡片布局和动画效果
- **直观操作**: 简洁的表单设计和清晰的结果展示

### 2. 评论输入
- **文本输入**: 支持最多5000字符的评论输入
- **字符计数**: 实时显示字符数量和剩余空间
- **元数据支持**: 可选的地点名称和ID输入

### 3. 结果展示
- **评分可视化**: 质量和相关性评分的进度条展示
- **违规检测**: 清晰标示各项政策违规检测结果
- **评估总结**: 自动生成的评估总结文本
- **动画效果**: 平滑的结果展示动画

### 4. 交互功能
- **实时验证**: 表单输入验证和错误提示
- **加载状态**: 评估过程中的加载动画
- **结果导出**: 将评估结果导出为文本文件
- **重置功能**: 一键清空表单和结果

### 5. 用户体验
- **通知系统**: 成功、错误、警告等状态通知
- **模态框**: 关于项目的详细信息展示
- **平滑滚动**: 自动滚动到结果区域
- **键盘支持**: 完整的键盘导航支持

## 快速开始

### 1. 环境要求

- 现代Web浏览器（Chrome、Firefox、Safari、Edge）
- 本地Web服务器（可选，用于避免CORS问题）

### 2. 直接使用

可以直接在浏览器中打开 `index.html` 文件：

```bash
# 在浏览器中打开
open index.html  # macOS
start index.html # Windows
xdg-open index.html # Linux
```

### 3. 使用本地服务器（推荐）

```bash
# 使用Python内置服务器
cd frontend
python3 -m http.server 3000

# 或使用Node.js的http-server
npx http-server -p 3000

# 或使用PHP内置服务器
php -S localhost:3000
```

然后在浏览器中访问 `http://localhost:3000`

### 4. 配置后端API地址

编辑 `js/main.js` 文件，修改API基础地址：

```javascript
constructor() {
    this.apiBaseUrl = 'http://localhost:8000'; // 修改为实际的PHP后端地址
    this.init();
}
```

## API 集成

前端通过以下方式与PHP后端进行通信：

### 1. 评论评估API

```javascript
// 请求格式
const requestData = {
    review_text: "用户输入的评论文本",
    location_metadata: {
        location_name: "可选的地点名称",
        location_id: "可选的地点ID"
    }
};

// 调用API
const result = await fetch('http://localhost:8000/api/evaluate-review', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestData)
});
```

### 2. 错误处理

前端包含完整的错误处理机制：
- 网络错误处理
- API响应错误处理
- 用户输入验证
- 友好的错误消息显示

## 自定义和扩展

### 1. 修改样式

编辑 `css/style.css` 文件来自定义：
- 颜色主题
- 字体和排版
- 布局和间距
- 动画效果

### 2. 添加新功能

在 `js/main.js` 中的 `ReviewAssessmentApp` 类中添加新方法：

```javascript
class ReviewAssessmentApp {
    // 添加新的功能方法
    newFeature() {
        // 实现新功能
    }
}
```

### 3. 集成第三方库

可以通过CDN或本地文件集成其他JavaScript库：

```html
<!-- 在index.html中添加 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
```

## 浏览器兼容性

- **Chrome**: 60+
- **Firefox**: 55+
- **Safari**: 12+
- **Edge**: 79+

主要使用的现代Web技术：
- ES6+ JavaScript (async/await, 类语法等)
- CSS Grid 和 Flexbox
- Fetch API
- CSS 自定义属性

## 性能优化

### 1. 已实现的优化
- CSS和JavaScript文件压缩
- 图片懒加载准备
- 事件委托
- 防抖处理

### 2. 进一步优化建议
- 使用Webpack或Vite进行打包
- 实现Service Worker缓存
- 图片格式优化（WebP）
- CDN加速

## 部署

### 1. 静态部署

可以将整个 `frontend` 目录部署到任何静态文件服务器：
- GitHub Pages
- Netlify
- Vercel
- AWS S3

### 2. 与后端集成部署

将前端文件放置到PHP项目的public目录中，实现前后端一体化部署。

## 故障排除

### 1. CORS错误

如果遇到跨域问题：
- 确保PHP后端已正确设置CORS头
- 使用本地服务器而不是直接打开HTML文件
- 检查API地址配置

### 2. API连接失败

- 确认PHP后端服务正在运行
- 检查API地址配置是否正确
- 查看浏览器开发者工具的网络面板

### 3. 样式问题

- 清除浏览器缓存
- 检查CSS文件路径
- 确认字体和图标CDN可访问

## 下一步开发

1. **数据可视化**: 集成Chart.js显示评估趋势
2. **批量评估**: 支持多条评论同时评估
3. **历史记录**: 本地存储评估历史
4. **主题切换**: 支持深色/浅色主题
5. **多语言支持**: 国际化功能
6. **PWA支持**: 离线使用能力

